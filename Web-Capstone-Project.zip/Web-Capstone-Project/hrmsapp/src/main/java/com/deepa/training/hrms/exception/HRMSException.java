package com.deepa.training.hrms.exception;

public class HRMSException extends Exception {
private String errorCode;
	
	public HRMSException() {
		super();
	}

	public HRMSException(String errorCode) {
		super(errorCode);
	}
	
	public HRMSException(String message,Throwable cause, String errorCode) {
		super(message);
		this.errorCode = errorCode;
	}
	

	public HRMSException(Throwable cause, String errorCode) {
		super(cause);
		this.errorCode = errorCode;
	}
	
	public HRMSException(String message, String errorCode) {
		super(message);
		this.errorCode = errorCode;
	}

}



