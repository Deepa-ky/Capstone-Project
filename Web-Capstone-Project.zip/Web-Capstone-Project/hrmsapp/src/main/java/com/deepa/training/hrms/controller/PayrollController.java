package com.deepa.training.hrms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.deepa.training.hrms.constants.Constants;
import com.deepa.training.hrms.dao.Connect;
import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Employee;
import com.deepa.training.hrms.service.PayrollService;
import com.deepa.training.hrms.service.PayrollServiceImpl;

/**
 * Servlet implementation class PayrollController
 */
public class PayrollController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PayrollController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn=null;
		int empid=Integer.parseInt(request.getParameter("empid"));
        String op = request.getParameter("oper");
		Employee emp = new Employee();
		emp.setEmpId(empid);
		HttpSession session = request.getSession(true);
		if(op.equals("check")) {
			PrintWriter pw = response.getWriter();
			PayrollService service = new PayrollServiceImpl();
			RequestDispatcher rd=null;
			try {
				if(service.isIdExists(emp)) {
					try {
						session.setAttribute("Emp_INFO", emp);
						conn=Connect.getConnection();
						PreparedStatement pstmt=conn.prepareStatement(Constants.SQL_SELECT_QUERY1);
						pstmt.setInt(1, empid);
						ResultSet rs = pstmt.executeQuery();  
						if (rs.next()) 
			             {  
			                 int empId= rs.getInt(1);
			                 String firstname=rs.getString(2);
			                 String lastname=rs.getString(3);
			                 String designation=rs.getString(4);
			                 int sal = rs.getInt(5);
			                 pw.println("\t\t\t\tPAYSLIP\t\t\t\t");
			                 pw.println("--------------------------------------------------------------------------\n\n");
			                 pw.println("\tEMployee ID: "+empId);
			                 pw.println("\tEMployee Name: "+firstname+lastname);
			                 pw.println("\tDesignation: "+designation); 
			                 pw.println("\tSalary: "+sal);
			                 pw.println("\n\n--------------------------------------------------------------------------");
			             }  
			            conn.close();  
					} catch (ClassNotFoundException e) {
						e.printStackTrace(); }
					 catch (SQLException e) {
						e.printStackTrace(); }
					} 
																			
				else {
						pw.println("<b>Employee ID does not exists</b>");
				}
			} catch (HRMSException e) {
				e.printStackTrace();
			}
		}}
		
	 /**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				doGet(request, response);
	}

}
