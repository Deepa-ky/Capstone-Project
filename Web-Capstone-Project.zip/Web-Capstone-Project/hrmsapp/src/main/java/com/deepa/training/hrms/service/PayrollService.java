package com.deepa.training.hrms.service;

import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Employee;

public interface PayrollService {
	public boolean isIdExists(Employee emp) throws HRMSException;
	}
