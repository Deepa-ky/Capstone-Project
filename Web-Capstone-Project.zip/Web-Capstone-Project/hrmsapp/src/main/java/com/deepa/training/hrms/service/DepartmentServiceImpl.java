package com.deepa.training.hrms.service;

import com.deepa.training.hrms.dao.DepartmentDao;
import com.deepa.training.hrms.dao.DepartmentDaoImpl;
import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Department;

public class DepartmentServiceImpl implements DepartmentService {
    DepartmentDao deldeptdao=new DepartmentDaoImpl();
	@Override
	public boolean isIdExists(Department dept) throws HRMSException {
		// TODO Auto-generated method stub
		return deldeptdao.isValidId(dept);
	}

}
