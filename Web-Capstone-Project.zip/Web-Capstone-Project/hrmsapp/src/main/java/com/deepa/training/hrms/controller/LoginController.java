package com.deepa.training.hrms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Login;
import com.deepa.training.hrms.service.HRMSLoginService;
import com.deepa.training.hrms.service.HRMSLoginServiceImpl;

/**
 * Servlet implementation class LoginController
 */
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public LoginController() {
        super();
            }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
        String op = request.getParameter("oper");
		
		Login emp = new Login();
		emp.setUsername(username);
		emp.setPassword(password);
		HttpSession session = request.getSession(true);
		
		if(op.equals("check")) {
			
			PrintWriter pw = response.getWriter();
			pw.println("Username: "+username);
			pw.println("Password: "+password);
			HRMSLoginService service = new HRMSLoginServiceImpl();
			RequestDispatcher rd=null;
			try {
				if(service.isUserExists(emp)) {
					session.setAttribute("Emp_INFO", emp);
					rd =  request.getRequestDispatcher("/jsp/hrms.jsp");
					rd.forward(request,response);
				}
				else {
					//failure path -login error.jsp
					rd =  request.getRequestDispatcher("/jsp/Login_Error.jsp");
					rd.forward(request,response);
				}
			} catch (HRMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
