package com.deepa.training.hrms.service;

import com.deepa.training.hrms.dao.PayrollDao;
import com.deepa.training.hrms.dao.PayrollDaoImpl;
import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Employee;

public class PayrollServiceImpl implements PayrollService{
    PayrollDao paydao=new PayrollDaoImpl();
	@Override
	public boolean isIdExists(Employee emp) throws HRMSException {
		// TODO Auto-generated method stub
		return paydao.isValidId(emp);
	}
	
}
