package com.deepa.training.hrms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.deepa.training.hrms.constants.Constants;
import com.deepa.training.hrms.dao.Connect;
import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Employee;
import com.deepa.training.hrms.model.Login;
import com.deepa.training.hrms.service.EmployeeService;
import com.deepa.training.hrms.service.EmployeeServiceImpl;
import com.deepa.training.hrms.service.HRMSLoginService;
import com.deepa.training.hrms.service.HRMSLoginServiceImpl;

/**
 * Servlet implementation class EmployeeController
 */
public class DelEmpController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DelEmpController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int empid=Integer.parseInt(request.getParameter("empid"));
        String op = request.getParameter("oper");
		Connection conn;
		Employee emp = new Employee();
		emp.setEmpId(empid);
		HttpSession session = request.getSession(true);
		
		if(op.equals("check")) {
			
			PrintWriter pw = response.getWriter();
			EmployeeService service = new EmployeeServiceImpl();
			RequestDispatcher rd=null;
			try {
				if(service.isIdExists(emp)) {
					try {
						conn=Connect.getConnection();
						PreparedStatement pstmt=conn.prepareStatement(Constants.SQL_DELETE_QUERY);
						session.setAttribute("Emp_INFO", emp);
						pstmt.setInt(1, empid);
						int count=pstmt.executeUpdate();
						rd =  request.getRequestDispatcher("/jsp/EmpDel_Success.jsp");
						rd.forward(request,response);
					    } 
					catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();   } 
					catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();  } }
					
				else {
					//failure path -login error.jsp
					pw.println("<B> Employee ID does not exists<B>");
				}
			} catch (HRMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
