package com.deepa.training.hrms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.deepa.training.hrms.constants.Constants;
import com.deepa.training.hrms.dao.Connect;
import com.deepa.training.hrms.model.Department;
import com.deepa.training.hrms.model.Employee;

/**
 * Servlet implementation class DispDeptController
 */
public class DispDeptController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DispDeptController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn=null;
		Department dept = new Department();
		HttpSession session = request.getSession(true);
		PrintWriter pw = response.getWriter();
			try {
				 session.setAttribute("Emp_INFO", dept);
				 conn=Connect.getConnection();
				 PreparedStatement pstmt=conn.prepareStatement(Constants.SQL_SELECT_QUERY3);
				 ResultSet rs = pstmt.executeQuery();  
				 pw.print("<table border=1><h3><b>List Of DEPARTMENTS</b></h3>");
                 pw.print("<tr><th>Department ID</th>");
                 pw.print("<th>Department Name</th>");
                 pw.print("<th>Location</th></tr>");
                 
						while(rs.next()) 
			             {  
			                 pw.print("<tr><td><center>"+rs.getInt(1)+"</center></td>");
			                 pw.print("<td><center>"+rs.getString(2)+"</center></td>");
			                 pw.print("<td><center>"+rs.getString(3)+"</center></td></tr>");
			                 	                 			                 
			             } 
						pw.print("</table>");
			            conn.close();  
					} catch (ClassNotFoundException e) {
						e.printStackTrace(); }
					 catch (SQLException e) {
						e.printStackTrace(); }
					} 

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
