package com.deepa.training.hrms.dao;

import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Employee;

public interface PayrollDao {
	public boolean isValidId(Employee emp) throws HRMSException;
	
}
