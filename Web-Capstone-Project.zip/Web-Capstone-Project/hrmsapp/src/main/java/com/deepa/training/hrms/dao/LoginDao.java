package com.deepa.training.hrms.dao;

import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Login;

public interface LoginDao {
	
	public boolean isValidUser(Login emp) throws HRMSException;

}
