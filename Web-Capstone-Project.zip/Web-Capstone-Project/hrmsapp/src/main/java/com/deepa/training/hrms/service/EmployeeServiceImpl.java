package com.deepa.training.hrms.service;

import com.deepa.training.hrms.dao.EmployeeDao;
import com.deepa.training.hrms.dao.EmployeeDaoImpl;
import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Employee;

public class EmployeeServiceImpl implements EmployeeService{
	
           EmployeeDao delemp=new EmployeeDaoImpl();

		@Override
		public boolean isIdExists(Employee emp) throws HRMSException {
			
			return delemp.isValidId(emp);
		}

	
		
	}


