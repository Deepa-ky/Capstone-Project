package com.deepa.training.hrms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.deepa.training.hrms.constants.Constants;
import com.deepa.training.hrms.exception.ErrorCode;
import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Department;

public class DepartmentDaoImpl implements DepartmentDao{

	@Override
	public boolean isValidId(Department dept) throws HRMSException {
		Connection conn = null;
		boolean isValid = false;
		try {
			conn = Connect.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(Constants.SQL_SELECT_QUERY5);
			pstmt.setInt(1,dept.getDeptId());

			// executing the query -reccord exist
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				isValid = true;
			}

		} catch (ClassNotFoundException e) {
			throw new HRMSException(e, ErrorCode.LOAD_DRIVER_ERROR);
		} catch (SQLException e) {
			throw new HRMSException(e, ErrorCode.SQL_SELECT_ERROR);
		} catch (Exception ce) {
			throw new HRMSException(ce, ErrorCode.SQL_UNKNOWN_ERROR);
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return isValid;
	}

}