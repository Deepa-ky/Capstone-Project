package com.deepa.training.hrms.service;

import com.deepa.training.hrms.dao.LoginDao;
import com.deepa.training.hrms.dao.LoginDaoImpl;
import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Login;

public class HRMSLoginServiceImpl implements HRMSLoginService{
     LoginDao ldao=new LoginDaoImpl();
	@Override
	public boolean isUserExists(Login emp) throws HRMSException {
		
		return ldao.isValidUser(emp);
	}
	
	

}
