package com.deepa.training.hrms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.deepa.training.hrms.constants.Constants;
import com.deepa.training.hrms.dao.Connect;
import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Employee;
import com.deepa.training.hrms.service.EmployeeService;
import com.deepa.training.hrms.service.EmployeeServiceImpl;

/**
 * Servlet implementation class AddEmpController
 */
public class AddEmpController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddEmpController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int empid=Integer.parseInt(request.getParameter("empid"));
		String fname=request.getParameter("firstname");
		String lname=request.getParameter("lastname");
		String desig=request.getParameter("designation");
		String department=request.getParameter("department");
		int sal=Integer.parseInt(request.getParameter("salary"));
        String op = request.getParameter("oper");
		Connection conn;
		PrintWriter pw=response.getWriter();
		Employee emp = new Employee();
		emp.setEmpId(empid);
		HttpSession session = request.getSession(true);
		EmployeeService service=new EmployeeServiceImpl();
		if(op.equals("check")) {
			try {
				if(!service.isIdExists(emp))
				 try {
						  conn=Connect.getConnection();
						  PreparedStatement pstmt=conn.prepareStatement(Constants.SQL_INSERT_QUERY);
						  pstmt.setInt(1, empid);
						  pstmt.setString(2, fname);
						  pstmt.setString(3, lname);
						  pstmt.setString(4, desig);
						  pstmt.setString(5, department);
						  pstmt.setInt(6, sal);
						  int count= pstmt.executeUpdate(); 
						  RequestDispatcher rd=null;
						  if(count>0) {
								rd =  request.getRequestDispatcher("/jsp/addEmp_Success.jsp");
								rd.forward(request,response);
							}
							else {
								//failure 
								rd =  request.getRequestDispatcher("/jsp/addEmp_Error.jsp");
								rd.forward(request,response);
							}
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				else {
					
					pw.println("<b>Duplicate Entry</b>");	
					}
				}
			catch (HRMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				}
				
			}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
