package com.deepa.training.hrms.dao;

import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Department;

public interface DepartmentDao {
	public boolean isValidId(Department dept) throws HRMSException;

}
