package com.deepa.training.hrms.constants;

public class Constants {
		
		public static final String DB_URL="jdbc:mysql://localhost/hrms";
		public static final String DB_USERNAME="root";
		public static final String DB_PWD="root";
		public static final String DB_DRIVER="com.mysql.cj.jdbc.Driver";
		
		//QUERY
		public static final String SQL_SELECT_QUERY="select user_name, password from login where user_name=? and password=?";
		public static final String SQL_SELECT_QUERY1="select emp_id,first_name,last_name,designation,salary from employee where emp_id=?";
        public static final String SQL_DELETE_QUERY="delete from employee where emp_id=?";
        public static final String SQL_SELECT_QUERY2="select *from employee";
        public static final String SQL_INSERT_QUERY="insert into employee values(?,?,?,?,?,?)";
        public static final String SQL_INSERT_QUERY1="insert into department values(?,?,?)";
        public static final String SQL_SELECT_QUERY3="select *from department";
        public static final String SQL_DELETE_QUERY1="delete from department where dept_id=?";
        public static final String SQL_SELECT_QUERY4="select *from employee where emp_id=?";
        public static final String SQL_SELECT_QUERY5="select *from department where dept_id=?";
}


