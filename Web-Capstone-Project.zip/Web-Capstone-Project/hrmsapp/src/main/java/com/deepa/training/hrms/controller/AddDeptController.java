package com.deepa.training.hrms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.deepa.training.hrms.constants.Constants;
import com.deepa.training.hrms.dao.Connect;
import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Department;
import com.deepa.training.hrms.service.DepartmentService;
import com.deepa.training.hrms.service.DepartmentServiceImpl;

/**
 * Servlet implementation class AddDeptController
 */
public class AddDeptController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddDeptController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int deptid=Integer.parseInt(request.getParameter("deptid"));
		String deptname=request.getParameter("deptname");
		String location=request.getParameter("location");
		String op = request.getParameter("oper");
		Connection conn;
		DepartmentService service=new DepartmentServiceImpl();
		PrintWriter pw=response.getWriter();
		Department dept = new Department();
		dept.setDeptId(deptid);
		HttpSession session = request.getSession(true);
		if(op.equals("check")) {
			try {
				if(!service.isIdExists(dept))
				 try {
						  conn=Connect.getConnection();
						  PreparedStatement pstmt=conn.prepareStatement(Constants.SQL_INSERT_QUERY1);
						  pstmt.setInt(1, deptid);
						  pstmt.setString(2, deptname);
						  pstmt.setString(3, location);
						  int count= pstmt.executeUpdate(); 
						  RequestDispatcher rd=null;
						  if(count>0) {
								rd =  request.getRequestDispatcher("/jsp/addDept_Success.jsp");
								rd.forward(request,response);
							}
							else {
								//failure 
								rd =  request.getRequestDispatcher("/jsp/addDept_Error.jsp");
								rd.forward(request,response);
							}
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				else {
					pw.println("<b>Duplicate Entry</b>");
				}
			} catch (HRMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				}
	}		
						

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
