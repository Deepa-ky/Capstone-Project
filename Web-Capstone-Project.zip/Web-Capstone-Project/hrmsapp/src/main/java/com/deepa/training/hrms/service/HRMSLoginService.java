package com.deepa.training.hrms.service;

import com.deepa.training.hrms.exception.HRMSException;
import com.deepa.training.hrms.model.Login;

public interface HRMSLoginService {
	public boolean isUserExists(Login emp) throws HRMSException;

}
