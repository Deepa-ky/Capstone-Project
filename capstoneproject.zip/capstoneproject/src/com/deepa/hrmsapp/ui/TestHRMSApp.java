package com.deepa.hrmsapp.ui;
import java.util.Scanner;

import javax.security.auth.login.LoginException;

import com.deepa.hrmsapp.controller.HRMSController;
import com.deepa.hrmsapp.domain.Department;
import com.deepa.hrmsapp.domain.Login;
import com.deepa.hrmsapp.exception.HRMSException;
import com.deepa.hrmsapp.repository.DepartmentDao;
import com.deepa.hrmsapp.repository.DepartmentDaoImpl;
import com.deepa.hrmsapp.repository.LoginDao;
import com.deepa.hrmsapp.repository.LoginDaoImpl;
public class TestHRMSApp {
    	public static void main(String[] args) throws ClassNotFoundException, HRMSException, LoginException {
		HRMSController hrmcon = new HRMSController();
		LoginDao ld=new LoginDaoImpl();
		DepartmentDao dd=new DepartmentDaoImpl();
		Login l=null;
		Department dept=null;
		ld.userLogin(l);
		System.out.println("1.Employee Details");
		System.out.println("2.Department Details");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter which details you want to see");
		int ch=sc.nextInt();
		if(ch==1) {
		System.out.println("Employee Details...");
		System.out.println("1.Adding New Employee");
		System.out.println("2.Displaying List of employees");
		System.out.println("3.Deletion of existing employee");
		System.out.println("-------------------------------------------------");
		System.out.print("Please enter the action that you want to perform:");
		int opt=sc.nextInt();
		System.out.println();
		hrmcon.empOp(opt);
		sc.close(); }
		else { 
	         	dd.disp(dept); 
	          }
		}
	}
	


