package com.deepa.hrmsapp.constants;

public class Constants {
	
	public static final String DB_DRIVER="com.mysql.cj.jdbc.Driver";
	public static final String DB_URL="jdbc:mysql://localhost/hrms";
	public static final String DB_USERNAME="root";
	public static final String DB_PASSWORD="root";

}
