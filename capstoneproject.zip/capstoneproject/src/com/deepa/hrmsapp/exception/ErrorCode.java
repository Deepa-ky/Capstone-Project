package com.deepa.hrmsapp.exception;

public class ErrorCode {
	public static final String INVALID_OPTION ="Invalid option, please select right option";
	public static final String INVALID_EMPID ="Pease enter valid empoyee id";
	public static final String DUPLICATE_ID ="Employee ID already exists";
	}
