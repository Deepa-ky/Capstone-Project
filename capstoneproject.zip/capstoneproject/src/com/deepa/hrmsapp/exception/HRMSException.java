package com.deepa.hrmsapp.exception;
@SuppressWarnings("serial")
public class HRMSException extends Exception{
	private String errorCode;
	public HRMSException() {}
	public HRMSException(String errorcode) {
		super();
		this.errorCode=errorcode;
			}
	public HRMSException(Throwable cause, String errorCode) {
		super(cause);
		this.errorCode=errorCode;
	}
	public HRMSException(String message, String errorCode) {
		super(message);
		this.errorCode=errorCode;
	}
	}
