package com.deepa.hrmsapp.exception;

public class LoginException {

}
