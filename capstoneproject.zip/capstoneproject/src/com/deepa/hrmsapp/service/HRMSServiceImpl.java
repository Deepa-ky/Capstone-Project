package com.deepa.hrmsapp.service;

import com.deepa.hrmsapp.domain.Employee;
import com.deepa.hrmsapp.exception.HRMSException;
import com.deepa.hrmsapp.repository.Dao;
import com.deepa.hrmsapp.repository.DaoImpl;

public class HRMSServiceImpl implements HRMSService {
	Dao dao=new DaoImpl();

	@Override
	public void display(Employee emp)
			throws HRMSException, ClassNotFoundException{
	      dao.display(emp);
		
	}

	@Override
	public void addEmp(Employee emp)
			throws HRMSException, ClassNotFoundException{
		    dao.addEmp(emp);
		
	}

	@Override
	public void delEmp(Employee emp) throws HRMSException,ClassNotFoundException {
		dao.delEmp(emp);
		
	}
    
}


