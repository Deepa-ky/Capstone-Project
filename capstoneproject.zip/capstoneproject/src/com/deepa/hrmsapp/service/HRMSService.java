package com.deepa.hrmsapp.service;

import com.deepa.hrmsapp.domain.Employee;
import com.deepa.hrmsapp.exception.HRMSException;

public interface HRMSService {
	public void display(Employee emp) throws HRMSException, ClassNotFoundException;
	public void addEmp(Employee emp)throws HRMSException, ClassNotFoundException;
	public void delEmp(Employee emp)throws HRMSException, ClassNotFoundException;
	}
