package com.deepa.hrmsapp.repository;

import javax.security.auth.login.LoginException;

import com.deepa.hrmsapp.domain.Login;

public interface LoginDao {
	public void userLogin(Login l) throws LoginException;

}
