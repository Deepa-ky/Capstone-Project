package com.deepa.hrmsapp.repository;

import com.deepa.hrmsapp.domain.Department;

public interface DepartmentDao {
	public void disp(Department dept) throws ClassNotFoundException;
}
