package com.deepa.hrmsapp.repository;

import java.sql.*;
import java.util.Scanner;
import com.deepa.hrmsapp.constants.Constants;
import com.deepa.hrmsapp.controller.HRMSController;
import com.deepa.hrmsapp.domain.Employee;
import com.deepa.hrmsapp.exception.HRMSException;
import com.deepa.hrmsapp.service.HRMSService;
import com.deepa.hrmsapp.service.HRMSServiceImpl;

public class DaoImpl implements Dao {
	@Override
    public void addEmp(Employee emp)throws HRMSException {
		int empID;
		String firstName;
		String lastName;
		String designation;
		String deptName;
		int salary;
		try {
			  Class.forName(Constants.DB_DRIVER);
			  Connection conn=DriverManager.getConnection(Constants.DB_URL,Constants.DB_USERNAME,Constants.DB_PASSWORD);
			  String query = "insert into employee values(?,?,?,?,?,?)";
			  PreparedStatement pst=conn.prepareStatement(query);	
			  Scanner sc=new Scanner(System.in);
			  // Reading employee details
			  System.out.print("Enter Employee Number:");
			  empID=sc.nextInt();
			  System.out.print("Enter firstname:");
			  firstName=sc.next();
			  System.out.print("Enter lastname :");
			  lastName=sc.next();
			  System.out.print("Enter  designation:");
			  designation=sc.next();
			  System.out.print("Enter  department name:");
			  deptName=sc.next();
			  System.out.print("Enter salary :");
			  salary=sc.nextInt();
		      // Execute a query
			  pst.setInt(1,empID);
			  pst.setString(2,firstName);
			  pst.setString(3,lastName);
			  pst.setString(4,designation);
			  pst.setString(5, deptName);
			  pst.setInt(6,salary);
		      pst.executeUpdate();
		      System.out.println("New Employee record has been added");
		      sc.close();
		      }  
		
	  catch (SQLException e) {
		         e.printStackTrace();
		      } catch (Exception e) {
		    	  e.printStackTrace();
		      } 
    }	
    @Override  
	public void display(Employee emp)throws HRMSException, ClassNotFoundException {
		try {
			  Class.forName(Constants.DB_DRIVER);
			  Connection conn=DriverManager.getConnection(Constants.DB_URL,Constants.DB_USERNAME,Constants.DB_PASSWORD);
			  Statement stmt=conn.createStatement();
			  ResultSet rs=stmt.executeQuery("select *from employee");
			  System.out.println("***************Employee Details************************");
			  System.out.println("----------------------------------------------------------------------------------------------");
			  System.out.println("EmployeeID\tFirstName\tLastName\tDesignation\tDepartmentName\tSalary");
			  System.out.println("----------------------------------------------------------------------------------------------");
			  while(rs.next())
			  {  System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2)+"\t\t"+rs.getString(3)+"\t\t"+rs.getString(4)+"\t\t"+rs.getString(5)+"\t\t"+rs.getInt(6));
		} 
			  System.out.println("----------------------------------------------------------------------------------------------");
			  conn.close();}
		catch(SQLException e) {e.printStackTrace();}
	}
    @Override
    public void delEmp(Employee emp) throws HRMSException, ClassNotFoundException {
		int empID;
    	try {
			  Class.forName(Constants.DB_DRIVER);
			  Connection conn=DriverManager.getConnection(Constants.DB_URL,Constants.DB_USERNAME,Constants.DB_PASSWORD);
			  System.out.print("Please Enter the Employee ID to be deleted from the Database:");
			  Scanner sc= new Scanner(System.in);
			  empID=sc.nextInt();
			  String sql = "Delete from employee where emp_id=?";
			  PreparedStatement pst=conn.prepareStatement(sql);
			  pst.setInt(1, empID);
			  int rowsDeleted = pst.executeUpdate();
			  if(rowsDeleted==1)
			     System.out.println(rowsDeleted+" record deleted");
			  else
				  System.out.println("Employee ID does not exists");
			  sc.close();        
		   }
		catch(Exception e) {}
	
	
    }
	

}
