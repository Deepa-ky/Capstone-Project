package com.deepa.hrmsapp.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.security.auth.login.LoginException;

import com.deepa.hrmsapp.constants.Constants;
import com.deepa.hrmsapp.domain.Login;

public class LoginDaoImpl implements LoginDao{
    String dbusername;
    String dbpassword;
    @Override
	public void userLogin(Login l) throws LoginException{
		    String username;
		    String password;
		    Scanner sc=new Scanner(System.in);
		    System.out.println("***************Login Screen******************");
		    System.out.println();
		    System.out.print("Enter Username: ");
		    username = sc.next();
		    System.out.print("Enter Password: ");
		    password = sc.next();
		    try {
		    Class.forName(Constants.DB_DRIVER);
		    Connection conn=DriverManager.getConnection(Constants.DB_URL, Constants.DB_USERNAME, Constants.DB_PASSWORD);
		    Statement stmt=conn.createStatement();
		    String SQL = "SELECT * FROM login WHERE user_name='" + username + "' && password='" + password + "'";
		    ResultSet rs = stmt.executeQuery(SQL);
            // Validate Username and Password
		    while (rs.next()) {
		        dbusername = rs.getString("user_name");
		        dbpassword = rs.getString("password");
		    }

		    if (username.equals(dbusername) && password.equals(dbpassword)) {
		        System.out.println("Login Successful\n------------------------------------------------");
		    } else {
		        System.out.println("Incorrect Username and Password, Please try again\n");
		        userLogin(l);
		          } 
		    }
		    catch(Exception e) {}
		
	}

}
