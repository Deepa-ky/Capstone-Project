package com.deepa.hrmsapp.repository;

import com.deepa.hrmsapp.domain.Employee;
import com.deepa.hrmsapp.exception.HRMSException;

public interface Dao {
	public void display(Employee emp) throws HRMSException,ClassNotFoundException;
	public void addEmp(Employee emp)throws HRMSException,ClassNotFoundException;
	public void delEmp(Employee emp)throws HRMSException,ClassNotFoundException;
	}
