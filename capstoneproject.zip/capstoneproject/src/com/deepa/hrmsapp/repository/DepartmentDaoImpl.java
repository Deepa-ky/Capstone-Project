package com.deepa.hrmsapp.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.deepa.hrmsapp.constants.Constants;
import com.deepa.hrmsapp.domain.Department;

public class DepartmentDaoImpl implements DepartmentDao{
	public void disp(Department dept) throws ClassNotFoundException {
	try {
		  Class.forName(Constants.DB_DRIVER);
		  Connection conn=DriverManager.getConnection(Constants.DB_URL,Constants.DB_USERNAME,Constants.DB_PASSWORD);
		  Statement stmt=conn.createStatement();
		  ResultSet rs=stmt.executeQuery("select *from Department");
		  System.out.println("***************Department Details********************");
		  System.out.println("----------------------------------------------------------------------------------------------");
		  System.out.println("Department ID\tDepartmentName\t\tLocation");
		  System.out.println("----------------------------------------------------------------------------------------------");
		  while(rs.next())
		  { 
			  System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2)+"\t\t\t"+rs.getString(3));
	      } 
		  System.out.println("----------------------------------------------------------------------------------------------");
		  conn.close();}
	catch(SQLException e) {e.printStackTrace();} 
	catch(Exception e)    {e.printStackTrace();}
} }

