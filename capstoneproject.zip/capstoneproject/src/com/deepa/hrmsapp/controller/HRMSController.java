package com.deepa.hrmsapp.controller;
import com.deepa.hrmsapp.domain.Employee;
import com.deepa.hrmsapp.exception.HRMSException;
import com.deepa.hrmsapp.service.HRMSService;
import com.deepa.hrmsapp.service.HRMSServiceImpl;

public class HRMSController {
	HRMSService  hrms=new HRMSServiceImpl();
	public void empOp(int option) throws HRMSException, ClassNotFoundException {
		Employee emp = null;
 		switch(option) {		
		   case 1: hrms.addEmp(emp); break;
	       case 2: hrms.display(emp); break;
	       case 3: hrms.delEmp(emp); break;
	        }      
	 	} } 
